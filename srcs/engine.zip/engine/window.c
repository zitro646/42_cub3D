/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: potero-d <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/28 12:16:17 by potero-d          #+#    #+#             */
/*   Updated: 2022/09/28 12:26:29 by potero-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

/*
 34 void    ray_vision(t_game *game, int color)
 35 {
 36     double  line;
 37     int     i;
 38     int     j;
 39
 40     line = 5;
 41     j = (game->player.c - 0.5) * 30 + 15;
 42     i = (game->player.f - 0.5) * 30 + 15;
 43     while (line < 10)
 44     {
 45         mlx_pixel_put(game->mlx.mlx, game->mlx.window,
 46                 j + (cos(game->player.angle) * line),
 47                 i + (sin(game->player.angle) * line), color);
 48         line += 0.2;
 49     }
 50 //  hit_pixel(game, 0);
 51     hit_pixel(game, 275, 0xF4D03F, 0xFFEB3B); // yellow
 52     hit_pixel(game, 375, 0x1D8348, 0x1D8348); //green
 53     hit_pixel(game, 475, 0xE74C3C, 0xE74C3C); //red
 54 //  hit_pixel(game, 749);
 55 }
 56 */

 /*
 61 void    player_vision_cone(t_game *game, int color)
 62 {
 63     ray_vision(game, color, 0);
 64     ray_vision(game, color, M_PI / 4);
 65     ray_vision(game, color, - M_PI / 4);
 66     return ;
 67 }
 68 */

/*
 61 void    player_pixel(t_game *game, int color)
 62 {
 63     int     i;
 64     int     j;
 65
 66     i = 10;
 67     while (i < 20)
 68     {
 69         j = 10;
 70         while (j < 20)
 71         {
 72         //  mlx_pixel_put(game->mlx.mlx, game->mlx.screen, 910 + j, 910 + i, color);
 73             mlx_pixel_put(game->mlx.mlx, game->mlx.window,
 74                 ((game->player.c - 0.5) * 30) + j, ((game->player.f - 0.5) * 30) + i, color);
 75             j++;
 76         }
 77         i++;
 78     }
 79     ray_vision(game, color);
 80 //  player_vision_cone(game, color);
 81 }
 82 */

/*
 72 void    wall_floor_pixel(t_game *game, int pos_f, int pos_c, int color)
 73 {
 74     int i;
 75     int j;
 76
 77     i = 0;
 78     while (i < 30)
 79     {
 80         j = 0;
 81         while (j < 30)
 82         {
 83             if (i == 0 || j == 0)
 84                 mlx_pixel_put(game->mlx.mlx, game->mlx.window,
 85                     ((pos_c * 30) + j), ((pos_f * 30 ) + i), 0x000000);
 86             else
 87                 mlx_pixel_put(game->mlx.mlx, game->mlx.window,
 88                     ((pos_c * 30) + j), ((pos_f * 30 ) + i), color);
 89             j++;
 90         }
 91         i++;
 92     }
 93 }
 94 */

void	window_aux(t_game *game, int pos_f, int pos_c)
 96 {
 97     double  aux;
 98
 99     aux = 0.5;
100 //  wall_floor_pixel(game, pos_f, pos_c, 0x8C8C8C);
101     if (game->matrix[pos_f][pos_c].value == 'N')
102     {
103         game->player.f = pos_f + aux;
104         game->player.c = pos_c + aux;
105         game->player.angle = 3 * M_PI / 2;
106     //  player_pixel(game, 0X0000FF);
107         game->matrix[pos_f][pos_c].value = '0';
108     }
109
110     else if (game->matrix[pos_f][pos_c].value == 'S')
111     {
112         game->player.f = pos_f + aux;
113         game->player.c = pos_c + aux;
114         game->player.angle = (M_PI / 2);
115     //  player_pixel(game, 0X0000FF);
116         game->matrix[pos_f][pos_c].value = '0';
117     }
118     else if (game->matrix[pos_f][pos_c].value == 'O')
119     {
120         game->player.f = pos_f  + aux ;
121         game->player.c = pos_c + aux;
122         game->player.angle = M_PI;
123     //  player_pixel(game, 0X0000FF);
124         game->matrix[pos_f][pos_c].value = '0';
125     }
126     else if (game->matrix[pos_f][pos_c].value == 'E')
127     {
128         game->player.f = pos_f + aux;
129         game->player.c = pos_c + aux;
130         game->player.angle = 0;
131     //  player_pixel(game, 0X0000FF);
132         game->matrix[pos_f][pos_c].value = '0';
133     }
134 }
void	window(t_game *game)
137 {
138     int pos_f;
139     int pos_c;
140
141     pos_f = 0;
142     while (pos_f < game->size_f)
143     {
144         pos_c = 0;
145         while (pos_c < game->size_c)
146         {
147         //  if (game->matrix[pos_f][pos_c].value == '1')
148         //      wall_floor_pixel(game, pos_f, pos_c, 0x4B0082);
149             // else if (game->matrix[pos_x][pos_y].value != '1')
150             if (game->matrix[pos_f][pos_c].value != '1')
151             {
152                 window_aux(game, pos_f, pos_c);
153             }
154             pos_c++;
155         }
156         pos_f++;
157     }
158 }
